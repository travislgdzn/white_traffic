import time
import sys
import numpy as np
import os

# load MNIST data
from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf

directory = sys.argv[1]
class_num = int(sys.argv[2])
round = int(sys.argv[3])
# diectory = 'E:\毕业设计\deeptraffic\DeepTraffic-master（可运行）\1.malware_traffic_classification\3.PreprocessedResults\20class\SessionAllLayers'
# class_num = 20
# round = 40000

dict_20class = {0: 'BitTorrent', 1: 'Facetime', 2: 'FTP', 3: 'Gmail', 4: 'MySQL', 5: 'Outlook', 6: 'Skype', 7: 'SMB',
                8: 'Weibo', 9: 'WorldOfWarcraft', 10: 'Cridex', 11: 'Geodo', 12: 'Htbot', 13: 'Miuref', 14: 'Neris',
                15: 'Nsis-ay', 16: 'Shifu', 17: 'Tinba', 18: 'Virut', 19: 'Zeus'}
dict = {}
fold = os.path.split(directory)[1]  #返回文件的路径和文件名
sess = tf.InteractiveSession()
flags = tf.app.flags
FLAGS = flags.FLAGS
flags.DEFINE_string('data_dir', directory, 'Directory for storing data')
mnist = input_data.read_data_sets(FLAGS.data_dir, one_hot=True)

# function: find a element in a list
def find_element_in_list(element, list_element):
    try:
        index_element = list_element.index(element)
        return index_element
    except ValueError:
        return -1

#  定义权重初始化
def weight(shape):
    init = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(init)

# 定义偏重初始化
def bias(shape):
    init = tf.constant(0.1, shape=shape)
    return tf.Variable(init)

# convolution
def conv2d(s, S):
    return tf.nn.conv2d(s, S, strides=[1, 1, 1, 1], padding='SAME')
#trides是一个一维具有四个元素的张量，其规定前后必须为1,中间两个数分别代表了水平滑动和垂直滑动步长值

# pooling
def pool(s):
    return tf.nn.max_pool(s, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

# Create the model
a = tf.placeholder("float", [None, 784])  # 原始输入
b = tf.placeholder("float", [None, class_num])
a_ = tf.reshape(a, [-1, 28, 28, 1])  # 2、3维表示图片的宽、高，最后一维表示图片的颜色通道（因为是灰度图像所以通道数维1，RGB图像通道数为3）

# first convolutinal layer
weight_conv1 = weight([5, 5, 1, 32])  # 第一二参数值得卷积核尺寸大小，即patch，第三个参数是图像通道数，第四个参数是卷积核的数目，代表会出现多少个卷积特征图像;
bias_conv1 = bias([32])  # 每一个输出通道都有一个偏置量
height_conv1 = tf.nn.relu(conv2d(a_, weight_conv1) + bias_conv1)  # 第一层的卷积结果,使用Relu作为激活函数
height_pool1 = pool(height_conv1)  # 第一层卷积后的池化结果

# second convolutional layer
weight_conv2 = weight([5, 5, 32, 64])
bias_conv2 = bias([64])
height_conv2 = tf.nn.relu(conv2d(height_pool1, weight_conv2) + bias_conv2)
height_pool2 = pool(height_conv2)

# densely connected layer
weight_fc1 = weight([7 * 7 * 64, 1024])  # 图片尺寸减小到7*7，加入一个有1024个神经元的全连接层
bias_fc1 = bias([1024])
height_flat = tf.reshape(height_pool2, [-1, 7 * 7 * 64])  # 将最后的池化层输出张量reshape成一维向量
height_fc1 = tf.nn.relu(tf.matmul(height_flat, weight_fc1) + bias_fc1)  # 全连接层输出

# dropout  使用Dropout减少过拟合
keep = tf.placeholder("float")
height_drop = tf.nn.dropout(height_fc1, keep)

# readout layer
weight_fc2 = weight([1024, class_num])
bias_fc2 = bias([class_num])
out = tf.nn.softmax(tf.matmul(height_drop, weight_fc2) + bias_fc2)

# training&testing
act_lab = tf.argmax(b, 1)
lab, id, num = tf.unique_with_counts(act_lab)
cross = -tf.reduce_sum(b * tf.log(out))  # 交叉熵损失
train = tf.train.GradientDescentOptimizer(1e-4).minimize(cross)
pre_lab = tf.argmax(out, 1)
lab_c, id_c, num_c = tf.unique_with_counts(pre_lab)  #out是预测结果，即神经网络输出   b是真实的的标签

cor_pre = tf.equal(pre_lab, act_lab)  # 正确预测,得到True或False的List
accu = tf.reduce_mean(tf.cast(cor_pre, "float"))  # 将布尔值转化成浮点数，取平均值作为精确度
cor_lab = tf.boolean_mask(act_lab, cor_pre)
lab_d, id_d, num_d = tf.unique_with_counts(cor_lab)

saver = tf.train.Saver()
model_name = "model_" + str(class_num) + "class_" + fold
model = model_name + '/' + model_name + ".ckpt"
start = time.time()
if not os.path.exists(model):
    sess.run(tf.initialize_all_variables())
    if not os.path.exists(model_name):
        os.makedirs(model_name)

    for i in range(round + 1):
        bat = mnist.train.next_batch(50)  # 每次取50个样本进行训练
        if i % 100 == 0:
            accuracy = accu.eval(feed_dict={a: bat[0], b: bat[1], keep: 1.0})
            s = "step %d, train accuracy %g" % (i, accuracy)
            print(s)

        train.run(feed_dict={a: bat[0], b: bat[1], keep: 0.5})

    save_path = saver.save(sess, model)
    print("Model saved in file:", save_path)
else:
    saver.restore(sess, model)
    print("Model restored: " + model)
stop1 = time.time()
# evaluate the model

if class_num == 20:
    dict = dict_20class

lab, num, lab_c, num_c, lab_d, num_d, acc = sess.run(
    [lab, num, lab_c, num_c, lab_d, num_d, accu],
    {a: mnist.test.images, b: mnist.test.labels, keep: 1.0})
stop2 = time.time()
acc_list = []
for i in range(class_num):
    n1 = find_element_in_list(i, lab.tolist())
    count_actual = num[n1]
    n2 = find_element_in_list(i, lab_d.tolist())
    count_correct = num_d[n2] if n2 > -1 else 0
    n3 = find_element_in_list(i, lab_c.tolist())
    count_predict = num_c[n3] if n3 > -1 else 0

    recall = float(count_correct) / float(count_actual)
    precision = float(count_correct) / float(count_predict) if count_predict > 0 else -1
    acc_list.append([str(i), dict[i], str(precision), str(recall)])
with open('result.txt', 'a') as f:
    f.write("\n")
    t = time.strftime('%Y-%m-%d %X', time.localtime())
    f.write(t + "\n")
    f.write('DIRECTORY: ' + directory + "\n")
    for item in acc_list:
        f.write(', '.join(item) + "\n")
    f.write('test accuracy: ' + str(acc) + "\n")
    f.write('train time: ' + str(stop1-start) + '秒' +'\n')
    f.write('test time: ' + str(stop2-stop1) + '秒' + '\n\n')